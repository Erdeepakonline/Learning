
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
      <div class="page-header">
        <h4 class="page-title">QUOTATION</h4>
        <ul class="breadcrumbs">
          <li class="nav-home">
            <a href="#">
              <i class="flaticon-home"></i>
            </a>
          </li>
          <!-- <li class="separator">
            <i class="flaticon-right-arrow"></i>
          </li>
          <li class="nav-item">
            <a href="#">Tables</a>
          </li> -->
          <li class="separator">
            <i class="flaticon-right-arrow"></i>
          </li>
          <li class="nav-item">
            <a href="#">Quotation</a>
          </li>
        </ul>
      </div>

      <div class="row">

        <div class="col-md-12">

          <div class="card crd1">
            <div class="card-header">
              <div class="d-flex align-items-center">
                <h4 class="card-title">Quotation List</h4>
                <a href="<?=base_url('admin/quotation/add')?>" class="btn btn-primary btn-sm btn-round ml-auto" >
                  <i class="fa fa-plus"></i>
                  New Quotation
                </a>
                <!-- <button class="btn btn-primary btn-sm btn-round ml-2"  data-toggle="modal" data-target="#leadMod">
                  <i class="fa fa-upload"></i> Upload Lead
                </button> -->
              </div>
            </div>
            <div class="card-body">

              <div class="table-responsive">
                <table id="datatbl" class="display table table-striped table-hover" >
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Client Name</th>
                      <th>Email Address</th>
                      <th>Mobile No.</th>
                      <th>Branch</th>
                      <th>Date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  </tbody>
                </table>
              </div>
            </div>
          </div>


          <div class="card crd2" style="display:none;">
            <div class="card-header">
              <div class="d-flex align-items-center">
                <h4 class="card-title">Quotation Detail</h4>
                <button class="btn btn-primary btn-sm btn-round ml-auto btnback">
                  <i class="fa fa-arrow-left"></i>
                  &nbsp; Back
                </button>
              </div>
            </div>
            <div class="card-body">
                <div class="qview">

                </div>
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>

</div>



<?php if($this->session->flashdata('quote_save') == 1) { ?>
<script>
  $(document).ready(function(){
  $.notify({
    icon: 'flaticon-hands',
    title: 'Record Saved',
    message: 'New Record Saved Successfully',
  },{
    type: 'success',
    placement: {
      from: "top",
      align: "right"
    },
    time: 1000,
  });
});
</script>
<?php } ?>

<?php if($this->session->flashdata('quote_save') == 2) { ?>
<script>
  $(document).ready(function(){
  $.notify({
    icon: 'flaticon-hands',
    title: 'Record Updated',
    message: 'Record Updated Successfully',
  },{
    type: 'success',
    placement: {
      from: "top",
      align: "right"
    },
    time: 1000,
  });
});
</script>
<?php } ?>

<script>
  $(document).ready(function(){

  var dtable =  $("#datatbl").DataTable( {
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
          url:"<?=base_url('admin/quotation/get_records')?>",
          type:"POST",
            data:{
              "id":"<?=$id?>",
              "type":"<?=$type?>"
            }
        },
        "columns": [
         { "data": "id" },
         { "data": "client_name" },
         { "data": "email" },
         { "data": "contact_no" },
         { "data": "branch_name" },
         { "data": "qdate" },
         { "data": "action" },
       ],

       "columnDefs":[
                {
              "targets": [0],
              "render": function(data, type, row, meta) {
                i = meta.settings.json.sno++;
                return i;
              }
            },{
                "width": "20%",
                "targets": [1],
                "render": function(data, type, row, meta) {
                  return '<a href="javascript:;" class="leadv" data-row-id="'+row.id+'">'+row.client_name+'</a>';
                }
              },
            {
            "targets": [6],
            "render": function(data, type, row, meta) {
                return '<div class="form-button-action">\
                        <a href="<?=base_url('admin/quotation/quote_print/')?>'+row.id+'/D" data-toggle="tooltip" title="Download PDF" class="btn btn-link btn-success btn-lg" data-original-title="Download PDF">\
                          <i class="fa fa-download"></i>\
                        </a>\
                        <a href="<?=base_url('admin/quotation/edit/')?>'+row.id+'" data-toggle="tooltip" title="Edit Lead" class="btn btn-link btn-primary btn-lg" data-row-id="'+row.id+'" data-original-title="Edit Lead">\
                          <i class="fa fa-edit"></i>\
                        </a>\
                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger delrow" data-row-id="'+row.id+'"  data-original-title="Remove">\
                          <i class="fa fa-times"></i>\
                        </button>\
                      </div>';
            }
          }
        ]
    } );


    $(document).on("click", ".leadv", function() {
      var id = $(this).attr('data-row-id');
      $(".crd1").slideUp();
      $(".crd2").fadeIn();
      $.ajax({
        type:'post',
        url:"<?=base_url('admin/quotation/quote_print/')?>"+id+'/V',
        data:"id="+id,
        // dataType:'json',
        success: function ( res ) {
          $(".qview").html(res);
          // console.log(res);
          // $("#uname").text(res.client_name);
          // $("#mob2").text(res.mobile);
          // $("#email2").text(res.email);
          // $("#city2").text(res.branch);
          // $("#prd").text(res.start_point+'-'+res.end_point);
          // $("#sts2").text(res.date);
          // $("#st4").css({'color':res.colors});
          // $("#logv").html('');
          // $.each(res.log, function(i, row){
          //   // <div class="avatar avatar-online">\
          //   //   <span class="avatar-title rounded-circle border border-white bg-info">J</span>\
          //   // </div>\
          //   $("#logv").append('<div class="d-flex">\
          //     <div class="flex-1 ml-3 pt-1">\
          //       <h6 class="text-uppercase fw-bold mb-1">'+row.title+' \
          //       <small class="pl-3" style="color:'+row.colors+'; font-size:12px">'+row.status_name+'</small></h6>\
          //       <span class="text-muted">'+row.description+'</span>\
          //     </div>\
          //     <div class="float-right pt-1">\
          //       <small class="text-muted" style="font-size:11px; text-align:right">'+row.created+'<br />'+row.ctime+'</small>\
          //     </div>\
          //   </div>\
          //   <div class="separator-dashed"></div>')
          // });
        }
      });

    });

    $(".btnback").click(function(){
      $(".crd1").slideDown();
      $(".crd2").fadeOut();
    });

    $(document).on("click", ".delrow", function() {
      var tr = $(this).closest('tr');
      var id = $(this).attr('data-row-id');

      swal.fire({
        icon:'warning',
        title: 'Are You Sure?',
        text: "You won't be able to recover it.",
        // showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Confirm',
        // denyButtonText: `Don't save`,
      }).then((result) => {
        // console.log(result);
        if(result.isConfirmed == true) {
        $.ajax({
          type:"post",
          url:'<?=base_url('admin/quotation/delete')?>',
          data:"id="+id,
          dataType:"json",
          success:function(res) {
            if(res.status == 1) {
              tr.fadeOut();
              $.notify({
                icon: 'flaticon-alarm-1',
                title: 'Lead Deleted',
                message: 'Lead Deleted Successfully',
              },{
                type: 'danger',
                placement: {
                  from: "top",
                  align: "right"
                },
                time: 1000,
              });
            }
          }
        })
        }
      })

    });

  });

</script>
