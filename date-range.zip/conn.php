<?php
	$conn=mysqli_connect("localhost", "root", "", "php_prct_db");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>