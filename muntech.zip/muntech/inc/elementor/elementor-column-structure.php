<?php
// Add custom field to column
if(!function_exists('muntech_custom_column_params')){
    add_filter('ct-custom-column/custom-params', 'muntech_custom_column_params');
    function muntech_custom_column_params(){
        return array(
            'sections' => array(
                array(
					'name'     => 'custom_section',
					'label'    => esc_html__( 'Bravis Settings', 'muntech' ),
					'tab'      => \Elementor\Controls_Manager::TAB_LAYOUT,
					'controls' => array(
                        array(
							'name'    => 'col_sticky',
							'label'   => esc_html__( 'Column Sticky', 'muntech' ),
							'type'    => \Elementor\Controls_Manager::SELECT,
							'options' => array(
								'none'           => esc_html__( 'No', 'muntech' ),
								'sticky' => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'default' => 'none',
                            'prefix_class' => 'ct-column-'
                        ),
                        array(
                            'name'    => 'col_offset',
                            'label'   => esc_html__( 'Column Offset', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'           => esc_html__( 'No', 'muntech' ),
                                'left' => esc_html__( 'Left', 'muntech' ),
                                'right' => esc_html__( 'Right', 'muntech' ),
                            ),
                            'default' => 'none',
                            'prefix_class' => 'col-offset-'
                        )
                    )
                )
            )
        );
    }
}