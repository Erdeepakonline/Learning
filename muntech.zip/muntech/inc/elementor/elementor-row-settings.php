<?php
// Add custom field to section
if(!function_exists('muntech_custom_section_params')){
    add_filter('ct-custom-section/custom-params', 'muntech_custom_section_params'); 
    function muntech_custom_section_params(){
        return array(
            'sections' => array(
                array(
                    'name'     => 'ct_row_settings',
                    'label'    => esc_html__( 'Bravis Settings', 'muntech' ),
                    'tab'      => \Elementor\Controls_Manager::TAB_LAYOUT,
                    'controls' => array(
                        array(
                            'name'    => 'header_fixed_transparent',
                            'label'   => esc_html__( 'Header Fixed Transparent', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'transparent'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'ct-header-fixed-',
                            'default'      => 'none',
                        ),
                        array(
                            'name'    => 'container_header_custom',
                            'label'   => esc_html__( 'Container Header Custom', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'container-custom'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'header-',
                            'default'      => 'none',
                        ),
                        array(
                            'name'    => 'container_1230_custom',
                            'label'   => esc_html__( 'Container 1230px', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'container-custom'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'c1230-',
                            'default'      => 'none',
                        ),
                        array(
                            'name'    => 'container_1350_custom',
                            'label'   => esc_html__( 'Container 1350px', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'container-custom'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'c1350-',
                            'default'      => 'none',
                        ),
                        array(
                            'name'    => 'container_1390_custom',
                            'label'   => esc_html__( 'Container 1390px', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'container-custom'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'c1390-',
                            'default'      => 'none',
                        ),

                        array(
                            'name'    => 'col_order',
                            'label'   => esc_html__( 'Column Order ( Screen < 1024px)', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'order'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'ct-column-',
                            'default'      => 'none',
                        ),

                        array(
                            'name'    => 'row_scroll_fixed',
                            'label'   => esc_html__( 'Row Scroll - Column Fixed', 'muntech' ),
                            'type'    => \Elementor\Controls_Manager::SELECT,
                            'options' => array(
                                'none'        => esc_html__( 'No', 'muntech' ),
                                'fixed'   => esc_html__( 'Yes', 'muntech' ),
                            ),
                            'prefix_class' => 'ct-row-scroll-',
                            'default'      => 'none',
                        ),

                    ),
                ),
            ),
        );
    }
}