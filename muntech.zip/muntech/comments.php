<?php
/**
 * The template for displaying comments.
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @package muntech
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
    return;
} ?>

<div id="comments" class="comments-area">

    <?php
    // You can start editing here -- including this comment!
    if ( have_comments() ) : ?>
        <div class="comment-list-wrap">
            <h2 class="comments-title">
                <?php
                    $comment_count = get_comments_number();
                    if ( 1 === intval($comment_count) ) {
                        echo esc_html__( ' Popular Comment (1)', 'muntech' );
                    } else {
                        echo esc_html__('Popular Comments', 'muntech').' ('.esc_attr( $comment_count ).')';
                    }
                ?>
            </h2><!-- .comments-title -->
            <p class="decs-comment">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
            <?php the_comments_navigation(); ?>

            <ul class="comment-list">
                <?php
                    wp_list_comments( array(
                        'style'      => 'ul',
                        'short_ping' => true,
                        'callback'   => 'muntech_comment_list',
                        'max_depth'  => 3
                    ) );
                ?>
            </ul><!-- .comment-list -->

            <?php the_comments_navigation(); ?>
        </div>
        <?php if ( ! comments_open() ) : ?>
            <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'muntech' ); ?></p>
        <?php
        endif;

    endif; // Check for have_comments().

$args = array(
        'id_form'           => 'commentform',
        'id_submit'         => 'submit',
        'title_reply'       => esc_attr__( 'Leave A Comment', 'muntech'),
        'title_reply_to'    => esc_attr__( 'Leave A Comment To ', 'muntech') . '%s',
        'cancel_reply_link' => esc_attr__( 'Cancel Comment', 'muntech'),
        'label_submit'      => esc_attr__( 'SEND YOUR COMMENTS', 'muntech'),
        'comment_notes_before' => '',
        'fields' => apply_filters( 'comment_form_default_fields', array(

                'author' =>
                '<div class="row "><div class="comment-form-author col-lg-6 col-md-6 col-sm-12 comment-field-icon">'.
                '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
                '" size="30" placeholder="'.esc_attr__('Name', 'muntech').'"/></div>',

                'email' =>
                '<div class="comment-form-email col-lg-6 col-md-6 col-sm-12 comment-field-icon">'.
                '<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
                '" size="30" placeholder="'.esc_attr__('Email', 'muntech').'"/></div></div>',

                'website' =>
                '<div class="row-two"><div class="comment-field-icon comment-form-website">'.
                '<input id="website" name="url" type="text" value="" size="30" placeholder="'.esc_attr__('Website', 'muntech').'"/></div></div>',
        )
        ),
        'comment_field' =>  '<div class="comment-form-comment comment-field-icon"><textarea id="comment" name="comment" cols="45" rows="8" placeholder="'.esc_attr__('Comment', 'muntech').'" aria-required="true">' .
        '</textarea></div>',
);
comment_form($args);
?>

</div><!-- #comments -->