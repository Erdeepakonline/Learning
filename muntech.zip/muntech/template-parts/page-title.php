<?php
$titles = muntech_get_page_titles();

$pagetitle = muntech_get_opt( 'pagetitle', 'show' );
$ptitle_bg_overlay = muntech_get_opt( 'ptitle_bg_overlay');
$custom_pagetitle = muntech_get_page_opt( 'custom_pagetitle', 'themeoption');
if($custom_pagetitle != 'themeoption' && $custom_pagetitle != '') {
    $pagetitle = $custom_pagetitle;
}
$sub_title = muntech_get_page_opt( 'sub_title' );
$sub_title_position = muntech_get_page_opt( 'sub_title_position', 'bottom-title' );
ob_start();
if ( $titles['title'] )
{
    printf( '<h1 class="page-title">%s</h1>', wp_kses_post($titles['title']) );
}
$titles_html = ob_get_clean();
$ptitle_breadcrumb_on = muntech_get_opt( 'ptitle_breadcrumb_on', 'show' );
// if(is_404()) {
//     return true;
// }
if($pagetitle == 'show') : ?>
    <div id="pagetitle" class="page-title bg-image <?php if(!empty($ptitle_bg_overlay['color'])) { echo 'hide-overlay'; } ?>">
        <div class="container">
            <div class="page-title-inner">
                <div class="page-title-holder">
                    <?php if(!empty($sub_title)) : ?>
                        <h6 class="page-sub-title"><?php echo esc_attr($sub_title); ?></h6>
                    <?php endif; ?>
                    <?php printf( '%s', wp_kses_post($titles_html)); ?>
                </div>

                <?php if($ptitle_breadcrumb_on == 'show') : ?>
                    <?php muntech_breadcrumb(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>