<?php
/**
 * Template part for displaying posts in loop
 *
 * @package muntech
 */
$archive_date_on = muntech_get_opt( 'archive_date_on', true );
$archive_categories_on = muntech_get_opt( 'archive_categories_on', false );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('single-hentry archive'); ?>>
    
    <?php if (has_post_thumbnail()) {
        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
        echo '<div class="entry-featured">'; ?>
            <a href="<?php echo esc_url( get_permalink()); ?>"><?php the_post_thumbnail('muntech-thumbnail-single'); ?></a>
        <?php echo '</div>';
    } ?>
    <div class="entry-body">
                <?php muntech_archive_meta(); ?>
        <h2 class="entry-title">
            <a href="<?php echo esc_url( get_permalink()); ?>" title="<?php the_title(); ?>">
                <?php if(is_sticky()) { ?>
                    <i class="bravisicon-tick"></i>
                <?php } ?>
                <?php the_title(); ?>
            </a>
        </h2>
        <div class="entry-excerpt">
            <?php
                muntech_entry_excerpt();
                wp_link_pages( array(
                    'before'      => '<div class="page-links">',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ) );
            ?>
        </div>
        <a class="btn" href="<?php echo esc_url( get_permalink()); ?>">
            Read More<i class="fa fa-arrow-right"></i>
        </a>
    </div>
</article><!-- #post -->