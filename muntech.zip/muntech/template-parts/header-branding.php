<?php
/**
 * Template part for displaying site branding
 */

$logo_m = muntech_get_opt( 'logo_m', array( 'url' => get_template_directory_uri().'/assets/images/logo-mobile.png', 'id' => '' ) );

if ($logo_m['url']) {
    printf(
        '<a class="logo-mobile" href="%1$s" title="%2$s" rel="home"><img src="%3$s" alt="%2$s"/></a>',
        esc_url( home_url( '/' ) ),
        esc_attr( get_bloginfo( 'name' ) ),
        esc_url( $logo_m['url'] )
    );
}