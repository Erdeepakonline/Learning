<style>
.form-control[readonly] {
  background: #fff !important;
}
</style>
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
      <div class="page-header">
        <h4 class="page-title">INVOICE</h4>
        <ul class="breadcrumbs">
          <li class="nav-home">
            <a href="<?=base_url('admin/dashboard')?>">
              <i class="flaticon-home"></i>
            </a>
          </li>
          <li class="separator">
            <i class="flaticon-right-arrow"></i>
          </li>
          <li class="nav-item">
           Create Invoice
          </li>
          <!-- <li class="separator">
            <i class="flaticon-right-arrow"></i>
          </li>
          <li class="nav-item">
            <a href="#">Ad</a>
          </li> -->
        </ul>
      </div>
      <div class="row">

        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="d-flex align-items-center">
                <h4 class="card-title">Create New Invoice</h4>
                <a href="<?=base_url('admin/quotation')?>" class="btn btn-sm btn-primary btn-round ml-auto" >
                  <i class="fa fa-list"></i> &nbsp;
                  View All
                </a>
              </div>
            </div>
            <div class="card-body">
              <form method="post"  data-parsley-validate="" id="invoice" />
              <div class="">
                <div class="row" >
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Client Name</label>
                      <input  type="text" class="form-control" name="data[client_name]" value="<?=$client_name?>" required data-parsley-required-message="Please enter client name" placeholder="Enter client name">
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Contact No.</label>
                      <input  type="text" class="form-control" name="data[contact_no]" value="<?=$contact_no?>" required data-parsley-required-message="Please enter contact number" data-parsley-type="number" maxlength="10" data-parsley-minlength="10" data-parsley-minlength-message="Contact number should be 10 digit only"  placeholder="Enter contact no.">
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Email Address</label>
                      <input type="email" name="data[email]" value="<?=$email?>" required data-parsley-required-message="Please enter your email address"  class="form-control" placeholder="Enter email address">
                    </div>
                  </div>
                </div>
                <div class="row" >
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Start Point</label>
                      <input type="text" name="data[start_point]" value="<?=$start_point?>" required  data-parsley-required-message="Please enter start point" class="form-control" placeholder="Enter start point">
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>End Point</label>
                      <input type="text" name="data[end_point]" value="<?=$end_point?>" required data-parsley-required-message="Please enter end point" class="form-control" placeholder="Enter end point">
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Date</label>
                      <input type="text" name="data[qdate]" value="<?=($qdate) ? date('d-m-Y', strtotime($qdate)) : ''?>" required data-parsley-required-message="Please select a date" class="form-control dps" style="background:#fff" placeholder="Select a date">
                    </div>
                  </div>
                </div>
                <div class="row" >
                 <!--  <div class="col-sm-4">
                    <div class="form-group form-group-default">
                      <label>Branch</label>
                      <select class="form-control" required data-parsley-required-message="Please select a branch" name="data[branch]">
                        <option value="">Select Branch</option>
                        <?php foreach ($branchs as $key => $val) { ?>
                          <option value="<?=$val['id']?>" <?=($branch == $val['id']) ? 'selected' : ''?>>
                            <?=$val['branch_name']?>
                          </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div> -->
                  <div class="col-sm-12">
                    <div class="form-group form-group-default">
                      <label>Full Address</label>
                      <input  type="text" class="form-control" value="<?=$address?>" name="data[address]" required data-parsley-required-message="Please enter client address." placeholder="Enter client address">
                    </div>
                  </div>
                </div>

                <div class="card-header">
                  <div class="d-flex align-items-center">
                    <h5 style="font-weight:bold">Services &amp; Charges</h5>
                    <!-- <button class="btn btn-primary btn-sm btn-round ml-auto">
                      <i class="fa fa-plus"></i>
                      Add New
                    </button> -->
                  </div>
                </div>

                <table id="add-row" class="display table mt-4" >
                  <thead>
                    <tr>
                      <td>
                        <div class="form-group form-group-default">
                          <label>Services </label>
                          <select class="form-control" id="srv">
                            <option value="">Select Service</option>
                            <?php foreach ($services as $key => $val) { ?>
                              <option><?=$val['service_name']?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </td>
                      <td>
                        <div class="form-group form-group-default">
                          <label>Additional</label>
                          <input  type="text" class="form-control" id="adl"  placeholder="Enter additional detail">
                        </div>
                      </td>
                      <td>
                        <div class="form-group form-group-default">
                          <label>Amount (INR)</label>
                          <input  type="text" class="form-control" id="amt"  placeholder="Enter enter amount">
                        </div>
                      </td>
                      <td>
                        <div class="form-button-action">
                          <a href="javascript:;" id="addrow" class="btn btn-primary btn-sm btn-round ml-auto">
                            <i class="fa fa-plus"></i>
                            Add New
                          </a>
                        </div>
                      </td>
                    </tr>
                  </thead>
                  <tbody id="tbody">
                    <?php foreach ($servs as $key => $val) { ?>
                      <tr>
                        <td><?=$val['service_name']?></td>
                        <td><?=$val['additional_info']?></td>
                        <td ><?=$val['amount']?><input type="hidden" class="amt" value="<?=$val['amount']?>" /></td>
                        <td><a href="javascript:;" title="" class="btn btn-link btn-danger dlrow">
                          <i class="fa fa-times"></i>
                        </a> </td>
                        </tr>
                    <?php } ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="3" class="text-right">
                        Total
                      </td>
                      <td>
                        <h5 id="total"><?=($subtotal) ? $subtotal : 0; ?></h5>
                      </td>
                    </tr>
                    <tr>
                      <td >
                        <div class="form-group form-group-default">
                          <label>GST Charges</label>
                          <select class="form-control" id="gst" required data-parsley-required-message="Please select a gst option">
                            <option value="">Select GST</option>

                            <optgroup label="GST">
                                <option data-gval="5" data-gst-type="1" <?=($gst_type == 1 && $gst_val == 5) ? 'selected' : ''?>>GST (5%)</option>
                              <option data-gval="12" data-gst-type="1" <?=($gst_type == 1 && $gst_val == 12) ? 'selected' : ''?>>GST (12%)</option>
                              <option data-gval="18" data-gst-type="1" <?=($gst_type == 1 && $gst_val == 18) ? 'selected' : ''?>>GST (18%)</option>
                              <option data-gval="28" data-gst-type="1" <?=($gst_type == 1 && $gst_val == 28) ? 'selected' : ''?>>GST (28%)</option>
                            </optgroup>

                            <optgroup label="IGST">
                              <option data-gval="5" data-gst-type="2" <?=($gst_type == 2 && $gst_val == 5) ? 'selected' : ''?>>IGST (5%)</option>
                              <option data-gval="12" data-gst-type="2" <?=($gst_type == 2 && $gst_val == 12) ? 'selected' : ''?>>IGST (12%)</option>
                              <option data-gval="18" data-gst-type="2" <?=($gst_type == 2 && $gst_val == 18) ? 'selected' : ''?>>IGST (18%)</option>
                              <option data-gval="28" data-gst-type="2" <?=($gst_type == 2 && $gst_val == 28) ? 'selected' : ''?>>IGST (28%)</option>
                            </optgroup>

                          </select>
                        </div>
                      </td>
                      <td></td>
                      <td id="gstvl"><?=$gst_amt?></td>
                      <td>
                        <h5 id="stotal"><?=$total?></h5>
                      </td>
                    </tr>
                  </tfoot>
                </table>
                <div class="row" >
                  <div class="col-sm-12">
                    <div class="form-group bg-light form-group-default text-danger">
                      <input type="checkbox" name="send_quot" value="1" /> &nbsp;
                      <b>Send quotation to client email address.</b>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <input type="hidden" id="gst2" name="data[gst_amt]" value="<?=($gst_amt)? $gst_amt : 0; ?>" />
                    <input type="hidden" id="sbt2" name="data[subtotal]" value="<?=($subtotal)? $subtotal : 0; ?>" />
                    <input type="hidden" id="tot2" name="data[total]" value="<?=($total)? $total : 0; ?>" />
                    <input type="hidden" name="rowid" value="<?=($id)? $id : 0; ?>" />
                    <div class="form-group form-group-default">
                      <button type="submit" class="btn btn-primary" >Submit</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<script>
function count_total () {
  amt = 0;
  $(".amt").each(function(){
    // console.log($(this).val());
    amt = amt+parseInt($(this).val());
  });

  $("#total").text(amt);
  $("#sbt2").val(amt);

  gst = parseInt($("#gst option:selected").attr('data-gval'));
  // $("#tot2").val((amt+gst));
  stot = (amt*gst)/100;
  $("#gstvl").text(stot);
  $("#gst2").val(stot);
  $("#stotal").text((amt+stot));
  $("#tot2").val(amt+stot);

}

  $("#addrow").click(function(){

    srv = $("#srv").val();
    adl = $("#adl").val();
    amt = $("#amt").val();
    msg = '';
    err = 0;
    if(srv.length == 0) {
      msg = "Please select a service";
      err = 1;
    } else if(amt.length == 0) {
      msg = "Please enter amount";
      err = 1;
    }

    if(err == 1) {

      $.notify({
        icon: 'flaticon-alarm',
        title: 'Error Found!',
        message: msg,
        },{
        type: 'danger',
        placement: {
          from: "top",
          align: "right"
        },
        time: 1000,
      });

    }

    if(err == 0) {

      $("#tbody").append('<tr>\
        <td>'+srv+' <input type="hidden" name="srvs[]" value="'+srv+'" /> </td> \
        <td>'+adl+' <input type="hidden" name="adls[]" value="'+adl+'" /></td> \
        <td >'+amt+' <input type="hidden" name="amts[]" class="amt" value="'+amt+'" /></td> \
        <td><a href="javascript:;" title="" class="btn btn-link btn-danger dlrow">\
              <i class="fa fa-times"></i> \
              </a> </td> \
        </tr>');

      $("#srv option:selected").prop('selected', false);
      $("#amt").val('');
      $("#adl").val('');

      // $.ajax({
      //   type:'POST',
      //   url:'<?=base_url()?>',
      //   data:'',
      //   success:function(){
      //
      //   }
      // })
      count_total();
    }
  });



  $(document).on('click', '.dlrow', function(){
      $(this).closest('tr').remove();
      count_total();
  });

  $("#gst").change(function(){
      gst = $(this).find('option:selected').attr('data-gval');
      total = parseInt($("#total").text());

      stot = (total*gst)/100;
      $("#gstvl").text(stot);
      $("#gst2").val(stot);
      $("#stotal").text(total+stot);
      $("#tot2").val(total+stot);
  });

  // +++++++++++++++++++++++++++++++++++++++//
  // ======     Save QUOTATION    ==========//
  // +++++++++++++++++++++++++++++++++++++++//


  $("#invoice").submit(function( e ){
    e.preventDefault();
    if($(this).parsley().validate() == true) {

      gtype = $("#gst option:selected").attr('data-gst-type');
      gval = $("#gst option:selected").attr('data-gval');

      fdata = new FormData(this);
      fdata.append("data[gst_type]", gtype);
      fdata.append("data[gst_val]", gval);

      $.ajax({
        type: 'post',
        url:'<?=base_url('admin/invoice/save_record')?>',
        contentType: false,
        cache: false,
        processData:false,
        data: fdata,
        dataType:'json',
        success: function ( res ) {
          if(res.status == 1) {

            window.location.href="<?=base_url('admin/invoice')?>";

          } 
          $("#invoice").reset();
        }
      });

    }

  })
</script>
