<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {
	function __construct() {
		parent::__construct();
		check_login();
		// $this->load->model('lead_model');
	}

  public function index() {
		$headr['nav']['tab'] = 'lead';
		// $headr['nav']['menu'] = 'status';
		//
		// $data['cities'] = $this->db->where(['status' => 1])->get("city")->result_array();
		// $data['prods'] = $this->db->where(['status' => 1])->get("product")->result_array();
		$this->load->view('admin/head');
		$this->load->view('admin/header', $headr);
		$this->load->view('admin/invoice/view', $data);
		$this->load->view('admin/footer');

	}

	public function create($id) {
		$data['branchs'] = $this->db->where(['status' => 1])->get("branch")->result_array();
		$data['services'] = $this->db->where(['status' => 1])->get("services")->result_array();
		$data=$this->db->where("id",$id)->get("quotation")->row_array();
		// print_r($data);
		$this->load->view('admin/head');
		$this->load->view('admin/header', $headr);
		$this->load->view('admin/invoice/create', $data);
		$this->load->view('admin/footer');
	}


	public function update_record() {

		$post = $this->input->post('data');
		$srvs = $this->input->post('srvs');
		$adls = $this->input->post('adls');
		$amts = $this->input->post('amts');
		
		$id = $this->input->post('rowid');
		$sqt = $this->input->post('send_quot');
		//
		if(!empty($post)) {
			if($id > 0) {
				$post['qdate'] = date('Y-m-d', strtotime($post['qdate']));
				$this->db->where("id",$id)->update('invoice', $post);
				$co = count($srvs);
				if($co >0) {
					$co--;
					for($i=0; $i<=$co; $i++) {
						$this->db->insert("quot_services", [
							"q_id" => $id,
							"service_name" => $srvs[$i],
							"additional_info" => $adls[$i],
							"amount" => $amts[$i],
						]);
					}
				}

				if($sqt == 1) {
					$file = $this->quote_print($id, 'F');
					$this->smail([
						'name' => $post['client_name'],
						'email' => $post['email'],
						'file' => $file,
					]);
				}
				$this->session->set_flashdata('invoice_save',2);
				echo json_encode(['status' =>2]);
			} 
			// else {
			// 	$post['qdate'] = date('Y-m-d', strtotime($post['qdate']));
			// 	$this->db->insert("quotation", $post);
			// 	$qid = $this->db->insert_id();
			// 	if($qid) {
			// 		$co = count($srvs);
			// 		if($co >0) {
			// 			$co--;
			// 			for($i=0; $i<=$co; $i++) {
			// 				$this->db->insert("quot_services", [
			// 					"q_id" => $qid,
			// 					"service_name" => $srvs[$i],
			// 					"additional_info" => $adls[$i],
			// 					"amount" => $amts[$i],
			// 				]);
			// 			}
			// 		}

			// 		if($sqt == 1) {
			// 			$file = $this->quote_print($qid, 'F');
			// 			$this->smail([
			// 				'name' => $post['client_name'],
			// 				'email' => $post['email'],
			// 				'file' => $file,
			// 			]);
			// 		}

			// 		$this->session->set_flashdata('quote_save', 1);
			// 		echo json_encode(['status' => 1]);
			// 	}

			// }
		} else {

		}

	
	}


	public function edit ($id) {

		$data = $this->db->where("id", $id)->get('invoice')->row_array();
		$data['branchs'] = $this->db->where(['status' => 1])->get("branch")->result_array();
		$data['services'] = $this->db->where(['status' => 1])->get("services")->result_array();

		$data['servs'] = $this->db->where("q_id", $data['id'])->get("quot_services")->result_array();

		$this->load->view('admin/head');
		$this->load->view('admin/header', $headr);
		$this->load->view('admin/invoice/edit', $data);
		$this->load->view('admin/footer');
	}



	public function invoice_print ($id, $act) {
		// echo $id;
		$adm = $this->db->select("company_name, logo, gst, address as com_addr")->where(['status'=>1])->get('admin_login')->row_array();

		$this->db->select("qt.*, bt.branch_name, bt.contact_no as b_mob, bt.adrsline1, bt.adrsline2");
		$this->db->from('quotation qt, branch bt');
		$this->db->where("qt.branch=bt.id");
		$data = $this->db->where("qt.id", $id)->get()->row_array();

		$items = $this->db->where("q_id", $id)->get('quot_services')->result_array();
		$data['qdate'] = date('d M Y', strtotime($data['qdate']));
		$row = '';

		$br = $this->db->select("*")->where(['id'=>$data['branch']])->get('branch')->row_array();

		$i=0;

		foreach ($items as $ik => $item) { $i++;
			$row .= '<tr>
								<td> '.$i.' 	</td>
								<td> '.$item['service_name'].' 	</td>
								<td> '.$item['additional_info'].' 	</td>
								<td align="right"> '.$item['amount'].' 	</td>
							</tr>';
			}

		$row .= '<tr>
							<th colspan="3" style="text-align:right">   Subtotal	</th>
							<th align="right"> '.$data['subtotal'].' 	</th>
						</tr>';

		if($data['gst_type'] == 1) {
				$row .= '<tr>
									<td colspan="3" style="text-align:right">   CGST('.($data['gst_val']/2).'%)	</td>
									<td align="right"> '.number_format(($data['gst_amt']/2),2).' 	</td>
								</tr>
								<tr>
									<td colspan="3" style="text-align:right">   SGST('.($data['gst_val']/2).'%)	</td>
									<td align="right"> '.number_format(($data['gst_amt']/2),2).' 	</td>
								</tr>';
		} else {
				$row .= '<tr>
									<td colspan="3" style="text-align:right">   IGST('.$data['gst_val'].'%)	</td>
									<td align="right"> '.$data['gst_amt'].' 	</td>
								</tr>';
		}

		$row .= '<tr style="background:#eee">
							<th colspan="3" style="text-align:right">   Total	</th>
							<th align="right"> '.$data['total'].' 	</th>
						</tr>';

		$htm = file_get_contents('./temp/print.php');

		$htm = str_replace('{{rows}}', $row, $htm);
		foreach ($data as $key => $val) {
			$htm = str_replace('{{'.$key.'}}', $val, $htm);
		}

		foreach ($adm as $key2 => $val2) {

			if($key2 == 'logo') {
				$htm = str_replace('{{logo}}', base_url('media/').$val2, $htm);
			} else {
				$htm = str_replace('{{'.$key2.'}}', $val2, $htm);
			}

		}

		foreach ($br as $key4 => $val4) {
				$htm = str_replace('{{'.$key4.'}}', $val4, $htm);
		}

		if($act == 'V') {
					echo $htm;
			} else {

			require ('./mpdf/vendor/autoload.php');

		  $mpdf = new \Mpdf\Mpdf(['format' => 'A4']);
	    $mpdf->WriteHTML($htm);

			if($act == 'F') {
				$mpdf->Output('./pdf/Invoice-'.$id.'.pdf', 'F');
				return 'Invoice-'.$id.'.pdf';
			} else {
				$mpdf->Output('Invoice-'.$id.'.pdf', $act);
			}

		}

	}


	public function save_record() {

		$post = $this->input->post('data');
		$srvs = $this->input->post('srvs');
		$adls = $this->input->post('adls');
		$amts = $this->input->post('amts');
		
		$id = $this->input->post('rowid');
		$sqt = $this->input->post('send_quot');
		//
		if(!empty($post)) {
			if($id > 0) {
				$post['qdate'] = date('Y-m-d', strtotime($post['qdate']));
				$this->db->insert('invoice', $post);
				$co = count($srvs);
				if($co >0) {
					$co--;
					for($i=0; $i<=$co; $i++) {
						$this->db->insert("quot_services", [
							"q_id" => $id,
							"service_name" => $srvs[$i],
							"additional_info" => $adls[$i],
							"amount" => $amts[$i],
						]);
					}
				}

				if($sqt == 1) {
					$file = $this->quote_print($id, 'F');
					$this->smail([
						'name' => $post['client_name'],
						'email' => $post['email'],
						'file' => $file,
					]);
				}
				$this->session->set_flashdata('invoice_save',1);
				echo json_encode(['status' =>1]);
			} 
			// else {
			// 	$post['qdate'] = date('Y-m-d', strtotime($post['qdate']));
			// 	$this->db->insert("quotation", $post);
			// 	$qid = $this->db->insert_id();
			// 	if($qid) {
			// 		$co = count($srvs);
			// 		if($co >0) {
			// 			$co--;
			// 			for($i=0; $i<=$co; $i++) {
			// 				$this->db->insert("quot_services", [
			// 					"q_id" => $qid,
			// 					"service_name" => $srvs[$i],
			// 					"additional_info" => $adls[$i],
			// 					"amount" => $amts[$i],
			// 				]);
			// 			}
			// 		}

			// 		if($sqt == 1) {
			// 			$file = $this->quote_print($qid, 'F');
			// 			$this->smail([
			// 				'name' => $post['client_name'],
			// 				'email' => $post['email'],
			// 				'file' => $file,
			// 			]);
			// 		}

			// 		$this->session->set_flashdata('quote_save', 1);
			// 		echo json_encode(['status' => 1]);
			// 	}

			// }
		} else {

		}

	
	}

	public function get_records() {

		$src = $this->input->post('search');
		$stats = $this->input->post('status');

		$meta['draw'] = $this->input->post('draw');
		$lim = $this->input->post('length');
		$start = $this->input->post('start');


	$this->db->select("ld.*");
	$this->db->from("invoice ld");

	if(strlen($src['value'])) {
		$this->db->like("ld.client_name", $src['value']);
	}

	$rows = $this->db->count_all_results('', false);
	$meta['recordsTotal'] = $rows;
	$meta['recordsFiltered'] = $rows;

	 $this->db->order_by("ld.id","desc");
	 $this->db->limit($lim,$start);
	 $data = $this->db->get()->result_array();

	 foreach ($data as $key => $val) {
		  $val['qdate'] = date("d M Y", strtotime($val['qdate']));
			$val['created'] = date("d M Y", strtotime($val['created']));
			$val['branch_name'] = $this->db->where("id", $val['branch'])->get("branch")->row()->branch_name;
			// $val['state'] = $this->db->where("id", $val['state'])->get("state")->row()->state;
			$res[] = $val;
	 }

	 $meta['sno'] = $start+1;
	 $meta['data'] = ($res) ? $res : '';

	 echo json_encode($meta);

	}

	public function delete() {
		$id = $this->input->post('id');
		if($id>0) {
			$this->db->where("id", $id)->delete('quotation');
			echo json_encode(['status' => 1]);
		}
	}


	public function get_row_info () {
		$id = $this->input->post('id');
		if($id) {
			$data = $this->db->where('id', $id)->get("quotation")->row_array();
			// $data['branch'] = $this->db->select()->where('branch', $id)->get("quot_services")->result_array();
			$data['items'] = $this->db->where('q_id', $id)->get("quot_services")->result_array();
			if(!empty($data)) {
				echo json_encode($data);
			}
		}
	}



	public function getInitials($string = null) {
    return array_reduce(
        explode(' ', $string),
        function ($initials, $word) {
            return sprintf('%s%s', $initials, substr($word, 0, 1));
        },
        ''
    );
}

public function smail($params) {

	extract($params);
	$adm = $this->db->get('admin_login')->row();
	$htm = file_get_contents('./system/email/enquiry.html');

	$data = $this->db->where("id",1)->get('admin_login')->row_array();

	$htm = str_replace('{{name}}', $name, $htm);
	foreach ($data as $key => $val) {
		$htm = str_replace('{{'.$key.'}}', $val, $htm);
	}


	 		$this->load->library('email');

			 $config['protocol']    = 'sendmail';
	     $config['smtp_host']    = MAIL_HOST;
	     $config['smtp_port']    = '465';
	     $config['smtp_timeout'] = '7';
	     $config['smtp_user']    = $adm->email;
	     $config['smtp_pass']    = $adm->email_pass;
	     $config['charset']    = 'utf-8';
	     $config['newline']    = "\r\n";
	     $config['mailtype'] = 'html'; // or html
	     // $config['validation'] = TRUE; // bool whether to validate email or not

	     $this->email->initialize($config);


	     $this->email->from('query@vrlogisticspackersmovers.com', 'VR Logistic');
	     $this->email->to($email);

	     $this->email->subject('Quotation | VR Logistic');
	     $this->email->message($htm);
			 $this->email->attach('./pdf/'.$file);
	     $this->email->send();

	     // echo $this->email->print_debugger();


}

}
